todo
====

* backwards compat, esp places where existing api allows strings
* stronger input validation?
* docs
