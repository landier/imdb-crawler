-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mar 16 Octobre 2012 à 00:54
-- Version du serveur: 5.5.9
-- Version de PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `DbSamples`
--

-- --------------------------------------------------------

--
-- Structure de la table `Casting`
--

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `DbSamples`.`Casting` AS select `m`.`Title` AS `Title`,`p`.`FirstName` AS `FirstName`,`p`.`LastName` AS `LastName`,`a`.`CharacterName` AS `CharacterName` from ((`DbSamples`.`Movie` `m` join `DbSamples`.`Actor` `a` on((`a`.`Movie_id` = `m`.`id`))) join `DbSamples`.`Person` `p` on((`p`.`id` = `a`.`Actor_id`)));

--
-- Contenu de la table `Casting`
--
-- utilisé (#1356 - View 'DbSamples.Casting' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them)

-- --------------------------------------------------------

--
-- Structure de la table `Director`
--

CREATE TABLE `Director` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Director_id` int(11) NOT NULL,
  `Movie_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DirectorMovie_uk` (`Director_id`,`Movie_id`),
  KEY `Director2Movie_fk` (`Movie_id`),
  KEY `Director2Person_fk` (`Director_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=66 ;

--
-- Contenu de la table `Director`
--

INSERT INTO `Director` VALUES(1, 3, 1);
INSERT INTO `Director` VALUES(2, 3, 2);
INSERT INTO `Director` VALUES(4, 3, 4);
INSERT INTO `Director` VALUES(31, 3, 32);
INSERT INTO `Director` VALUES(3, 6, 3);
INSERT INTO `Director` VALUES(5, 6, 5);
INSERT INTO `Director` VALUES(6, 6, 6);
INSERT INTO `Director` VALUES(7, 6, 7);
INSERT INTO `Director` VALUES(19, 15, 20);
INSERT INTO `Director` VALUES(33, 15, 34);
INSERT INTO `Director` VALUES(20, 16, 21);
INSERT INTO `Director` VALUES(24, 16, 25);
INSERT INTO `Director` VALUES(14, 18, 14);
INSERT INTO `Director` VALUES(34, 18, 35);
INSERT INTO `Director` VALUES(11, 23, 11);
INSERT INTO `Director` VALUES(15, 23, 15);
INSERT INTO `Director` VALUES(39, 23, 40);
INSERT INTO `Director` VALUES(37, 24, 38);
INSERT INTO `Director` VALUES(16, 25, 16);
INSERT INTO `Director` VALUES(17, 27, 17);
INSERT INTO `Director` VALUES(26, 27, 27);
INSERT INTO `Director` VALUES(18, 29, 19);
INSERT INTO `Director` VALUES(22, 29, 23);
INSERT INTO `Director` VALUES(8, 34, 8);
INSERT INTO `Director` VALUES(12, 34, 12);
INSERT INTO `Director` VALUES(64, 38, 9);
INSERT INTO `Director` VALUES(13, 39, 13);
INSERT INTO `Director` VALUES(9, 43, 9);
INSERT INTO `Director` VALUES(10, 44, 10);
INSERT INTO `Director` VALUES(29, 44, 30);
INSERT INTO `Director` VALUES(21, 49, 22);
INSERT INTO `Director` VALUES(23, 54, 24);
INSERT INTO `Director` VALUES(25, 58, 26);
INSERT INTO `Director` VALUES(27, 62, 28);
INSERT INTO `Director` VALUES(35, 62, 36);
INSERT INTO `Director` VALUES(28, 64, 29);
INSERT INTO `Director` VALUES(30, 67, 31);
INSERT INTO `Director` VALUES(32, 72, 33);
INSERT INTO `Director` VALUES(36, 80, 37);
INSERT INTO `Director` VALUES(65, 81, 37);
INSERT INTO `Director` VALUES(38, 85, 39);
INSERT INTO `Director` VALUES(40, 89, 41);
INSERT INTO `Director` VALUES(41, 91, 42);
INSERT INTO `Director` VALUES(42, 94, 43);
INSERT INTO `Director` VALUES(43, 98, 44);
INSERT INTO `Director` VALUES(44, 100, 45);
INSERT INTO `Director` VALUES(45, 101, 46);
INSERT INTO `Director` VALUES(46, 105, 47);

-- --------------------------------------------------------

--
-- Structure de la table `Edge`
--

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `DbSamples`.`Edge` AS (select concat('p',`a`.`Actor_id`,'m',`a`.`Movie_id`) AS `id`,'Actor' AS `label`,concat('p',`a`.`Actor_id`) AS `source`,concat('m',`a`.`Movie_id`) AS `target`,1 AS `weight` from `DbSamples`.`Actor` `a`) union (select concat('p',`d`.`Director_id`,'m',`d`.`Movie_id`) AS `id`,'Director' AS `label`,concat('p',`d`.`Director_id`) AS `source`,concat('m',`d`.`Movie_id`) AS `target`,2 AS `weight` from `DbSamples`.`Director` `d`);

--
-- Contenu de la table `Edge`
--
-- utilisé (#1356 - View 'DbSamples.Edge' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them)

-- --------------------------------------------------------

--
-- Structure de la table `Movie`
--

CREATE TABLE `Movie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(45) NOT NULL,
  `Year` year(4) DEFAULT NULL,
  `ImdbLink` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Title_UNIQUE` (`Title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=59 ;

--
-- Contenu de la table `Movie`
--

INSERT INTO `Movie` VALUES(1, 'Goodfellas', 1990, NULL);
INSERT INTO `Movie` VALUES(2, 'Taxi Driver', 1976, NULL);
INSERT INTO `Movie` VALUES(3, 'Heat', 1995, NULL);
INSERT INTO `Movie` VALUES(4, 'Casino', 1995, NULL);
INSERT INTO `Movie` VALUES(5, 'Collateral', 2004, NULL);
INSERT INTO `Movie` VALUES(6, 'The Insider', 1999, NULL);
INSERT INTO `Movie` VALUES(7, 'Public Enemies', 2009, NULL);
INSERT INTO `Movie` VALUES(8, 'Fight Club', 1999, NULL);
INSERT INTO `Movie` VALUES(9, 'The Matrix', 1999, NULL);
INSERT INTO `Movie` VALUES(10, 'Forrest Gump', 1994, NULL);
INSERT INTO `Movie` VALUES(11, 'C''era una volta il West', 1968, NULL);
INSERT INTO `Movie` VALUES(12, 'Se7en', 1995, NULL);
INSERT INTO `Movie` VALUES(13, 'The Usual Suspects', 1995, NULL);
INSERT INTO `Movie` VALUES(14, 'Pulp Fiction', 1994, NULL);
INSERT INTO `Movie` VALUES(15, 'Il buono, il brutto, il cattivo.', 1968, NULL);
INSERT INTO `Movie` VALUES(16, '12 Angry Men', 1957, NULL);
INSERT INTO `Movie` VALUES(17, 'Schindler''s List', 1993, NULL);
INSERT INTO `Movie` VALUES(19, 'The Dark Knight', 2008, NULL);
INSERT INTO `Movie` VALUES(20, 'The Shawshank Redemption', 1994, NULL);
INSERT INTO `Movie` VALUES(21, 'The Godfather', 1972, NULL);
INSERT INTO `Movie` VALUES(22, 'Léon', 1994, NULL);
INSERT INTO `Movie` VALUES(23, 'Memento', 2000, NULL);
INSERT INTO `Movie` VALUES(24, 'American History X', 1998, NULL);
INSERT INTO `Movie` VALUES(25, 'Apocalypse Now', 1979, NULL);
INSERT INTO `Movie` VALUES(26, 'Terminator 2: Judgment Day', 1991, NULL);
INSERT INTO `Movie` VALUES(27, 'Saving Private Ryan', 1998, NULL);
INSERT INTO `Movie` VALUES(28, 'The Shining', 1980, NULL);
INSERT INTO `Movie` VALUES(29, 'American Beauty', 1999, NULL);
INSERT INTO `Movie` VALUES(30, 'Back to the Future', 1985, NULL);
INSERT INTO `Movie` VALUES(31, 'The Pianist', 2002, NULL);
INSERT INTO `Movie` VALUES(32, 'The Departed', 2006, NULL);
INSERT INTO `Movie` VALUES(33, 'Gladiator', 2000, NULL);
INSERT INTO `Movie` VALUES(34, 'The Green Mile', 1999, NULL);
INSERT INTO `Movie` VALUES(35, 'Reservoir Dogs', 1992, NULL);
INSERT INTO `Movie` VALUES(36, 'Full Metal Jacket', 1987, NULL);
INSERT INTO `Movie` VALUES(37, 'The Big Lebowski', 1998, NULL);
INSERT INTO `Movie` VALUES(38, 'Gran Torino', 2008, NULL);
INSERT INTO `Movie` VALUES(39, 'Snatch', 2000, NULL);
INSERT INTO `Movie` VALUES(40, 'Per qualche dollaro in più', 1965, NULL);
INSERT INTO `Movie` VALUES(41, 'Scarface', 1983, NULL);
INSERT INTO `Movie` VALUES(42, 'The Deer Hunter', 1978, NULL);
INSERT INTO `Movie` VALUES(43, 'Sin City', 2005, NULL);
INSERT INTO `Movie` VALUES(44, 'The King''s Speech', 2010, NULL);
INSERT INTO `Movie` VALUES(45, 'Into the Wild', 2007, NULL);
INSERT INTO `Movie` VALUES(46, 'Good Will Hunting', 1997, NULL);
INSERT INTO `Movie` VALUES(47, 'Twelve Monkeys', 1995, NULL);
INSERT INTO `Movie` VALUES(48, 'Big Fish', 2003, NULL);
INSERT INTO `Movie` VALUES(58, 'The Bourne Ultimatum', 2007, 'http://www.imdb.com/title/tt0440963/');

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `Node`
--
CREATE TABLE `Node` (
`id` varchar(12)
,`label` varchar(91)
);
-- --------------------------------------------------------

--
-- Structure de la table `Person`
--

CREATE TABLE `Person` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(45) NOT NULL,
  `LastName` varchar(45) NOT NULL,
  `Gender` tinyint(1) DEFAULT NULL,
  `BirthDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `FirstNameLastName_uk` (`FirstName`,`LastName`),
  KEY `FirstNameLastName_idx` (`FirstName`,`LastName`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=110 ;

--
-- Contenu de la table `Person`
--

INSERT INTO `Person` VALUES(1, 'Bruce', 'Willis', 1, NULL);
INSERT INTO `Person` VALUES(2, 'Robert', 'De Niro', 1, NULL);
INSERT INTO `Person` VALUES(3, 'Martin', 'Scorsese', 1, NULL);
INSERT INTO `Person` VALUES(4, 'Ray', 'Liotta', 1, NULL);
INSERT INTO `Person` VALUES(5, 'Joe', 'Pesci', 1, NULL);
INSERT INTO `Person` VALUES(6, 'Michael', 'Mann', 1, NULL);
INSERT INTO `Person` VALUES(7, 'Al', 'Pacino', 1, NULL);
INSERT INTO `Person` VALUES(8, 'Val', 'Kilmer', 1, NULL);
INSERT INTO `Person` VALUES(9, 'Sharon', 'Stone', 0, NULL);
INSERT INTO `Person` VALUES(10, 'Tom', 'Cruise', 1, NULL);
INSERT INTO `Person` VALUES(11, 'Russel', 'Crowe', 1, NULL);
INSERT INTO `Person` VALUES(12, 'Johnny', 'Depp', 1, NULL);
INSERT INTO `Person` VALUES(13, 'Morgan', 'Freeman', 1, NULL);
INSERT INTO `Person` VALUES(14, 'Tim', 'Robbins', 1, NULL);
INSERT INTO `Person` VALUES(15, 'Frank', 'Darabont', 1, NULL);
INSERT INTO `Person` VALUES(16, 'Francis Ford', 'Coppola', 1, NULL);
INSERT INTO `Person` VALUES(17, 'Marlon', 'Brando', 1, NULL);
INSERT INTO `Person` VALUES(18, 'Quentin', 'Tarantino', 1, NULL);
INSERT INTO `Person` VALUES(19, 'John', 'Travolta', 1, NULL);
INSERT INTO `Person` VALUES(20, 'Samuel L.', 'Jackson', 1, NULL);
INSERT INTO `Person` VALUES(21, 'Tim', 'Roth', 1, NULL);
INSERT INTO `Person` VALUES(22, 'Uma', 'Thurman', 0, NULL);
INSERT INTO `Person` VALUES(23, 'Sergio', 'Leone', 1, NULL);
INSERT INTO `Person` VALUES(24, 'Clint', 'Eastwood', 1, NULL);
INSERT INTO `Person` VALUES(25, 'Sidney', 'Lumet', 1, NULL);
INSERT INTO `Person` VALUES(26, 'Henry', 'Fonda', 1, NULL);
INSERT INTO `Person` VALUES(27, 'Steven', 'Spielberg', 1, NULL);
INSERT INTO `Person` VALUES(28, 'Liam', 'Neeson', 1, NULL);
INSERT INTO `Person` VALUES(29, 'Christopher', 'Nolan', 1, NULL);
INSERT INTO `Person` VALUES(30, 'Christian', 'Bale', 1, NULL);
INSERT INTO `Person` VALUES(31, 'Aaron', 'Eckhart', 1, NULL);
INSERT INTO `Person` VALUES(32, 'Michael', 'Caine', 1, NULL);
INSERT INTO `Person` VALUES(33, 'Heath', 'Ledger', 1, NULL);
INSERT INTO `Person` VALUES(34, 'David', 'Fincher', 1, NULL);
INSERT INTO `Person` VALUES(35, 'Edward', 'Norton', 1, NULL);
INSERT INTO `Person` VALUES(36, 'Brad', 'Pitt', 1, NULL);
INSERT INTO `Person` VALUES(37, 'Benicio', 'Del Toro', 1, NULL);
INSERT INTO `Person` VALUES(38, 'Lana', 'Wachowski', 1, NULL);
INSERT INTO `Person` VALUES(39, 'Bryan', 'Singer', 1, NULL);
INSERT INTO `Person` VALUES(40, 'Claudia', 'Cardinale', 0, NULL);
INSERT INTO `Person` VALUES(41, 'Charles', 'Bronson', 1, NULL);
INSERT INTO `Person` VALUES(42, 'Gwyneth', 'Paltrow', 0, NULL);
INSERT INTO `Person` VALUES(43, 'Andy', 'Wachowski', 1, NULL);
INSERT INTO `Person` VALUES(44, 'Robert', 'Zemeckis', 1, NULL);
INSERT INTO `Person` VALUES(45, 'Keanu', 'Reeves', 1, NULL);
INSERT INTO `Person` VALUES(46, 'Laurence', 'Fishburne', 1, NULL);
INSERT INTO `Person` VALUES(47, 'Tom', 'Hanks', 1, NULL);
INSERT INTO `Person` VALUES(48, 'Kevin', 'Spacey', 1, NULL);
INSERT INTO `Person` VALUES(49, 'Luc', 'Besson', 1, NULL);
INSERT INTO `Person` VALUES(50, 'Jean', 'Reno', 1, NULL);
INSERT INTO `Person` VALUES(51, 'Gary', 'Oldman', 1, NULL);
INSERT INTO `Person` VALUES(52, 'Natalie', 'Portman', 0, NULL);
INSERT INTO `Person` VALUES(53, 'Guy', 'Pearce', 1, NULL);
INSERT INTO `Person` VALUES(54, 'Tony', 'Kaye', 1, NULL);
INSERT INTO `Person` VALUES(55, 'Edward', 'Furlong', 1, NULL);
INSERT INTO `Person` VALUES(56, 'Martin', 'Sheen', 1, NULL);
INSERT INTO `Person` VALUES(57, 'Robert', 'Duvall', 1, NULL);
INSERT INTO `Person` VALUES(58, 'James', 'Cameron', 1, NULL);
INSERT INTO `Person` VALUES(59, 'Arnold', 'Schwarzenegger', 1, NULL);
INSERT INTO `Person` VALUES(60, 'Vin', 'Diesel', 1, NULL);
INSERT INTO `Person` VALUES(61, 'Matt', 'Damon', 1, NULL);
INSERT INTO `Person` VALUES(62, 'Stanley', 'Kubrick', 1, NULL);
INSERT INTO `Person` VALUES(63, 'Jack', 'Nicholson', 1, NULL);
INSERT INTO `Person` VALUES(64, 'Sam', 'Mendes', 1, NULL);
INSERT INTO `Person` VALUES(65, 'Michael J.', 'Fox', 1, NULL);
INSERT INTO `Person` VALUES(66, 'Christopher', 'Lloyd', 1, NULL);
INSERT INTO `Person` VALUES(67, 'Roman', 'Polanski', 1, NULL);
INSERT INTO `Person` VALUES(68, 'Adrien', 'Brody', 1, NULL);
INSERT INTO `Person` VALUES(69, 'Leonardo', 'DiCaprio', 1, NULL);
INSERT INTO `Person` VALUES(70, 'Mark', 'Wahlberg', 1, NULL);
INSERT INTO `Person` VALUES(71, 'Alec', 'Baldwin', 1, NULL);
INSERT INTO `Person` VALUES(72, 'Ridley', 'Scott', 1, NULL);
INSERT INTO `Person` VALUES(73, 'Joaquin', 'Phoenix', 1, NULL);
INSERT INTO `Person` VALUES(74, 'Barry', 'Pepper', 1, NULL);
INSERT INTO `Person` VALUES(75, 'Michael Clarke', 'Duncan', 1, NULL);
INSERT INTO `Person` VALUES(76, 'Harvey', 'Keitel', 1, NULL);
INSERT INTO `Person` VALUES(77, 'Michael', 'Madsen', 1, NULL);
INSERT INTO `Person` VALUES(78, 'Chris', 'Penn', 1, NULL);
INSERT INTO `Person` VALUES(79, 'Steve', 'Buscemi', 1, NULL);
INSERT INTO `Person` VALUES(80, 'Joel', 'Coen', 1, NULL);
INSERT INTO `Person` VALUES(81, 'Ethan', 'Coen', 1, NULL);
INSERT INTO `Person` VALUES(82, 'Jeff', 'Bridges', 1, NULL);
INSERT INTO `Person` VALUES(83, 'John', 'Goodman', 1, NULL);
INSERT INTO `Person` VALUES(84, 'Philip Seymour', 'Hoffman', 1, NULL);
INSERT INTO `Person` VALUES(85, 'Guy', 'Ritchie', 1, NULL);
INSERT INTO `Person` VALUES(86, 'Vinnie', 'Jones', 1, NULL);
INSERT INTO `Person` VALUES(87, 'Jason', 'Statham', 1, NULL);
INSERT INTO `Person` VALUES(88, 'Lee', 'Van Cleef', 1, NULL);
INSERT INTO `Person` VALUES(89, 'Brian', 'De Palma', 1, NULL);
INSERT INTO `Person` VALUES(90, 'Michelle', 'Pfeiffer', 0, NULL);
INSERT INTO `Person` VALUES(91, 'Michael', 'Cimino', 1, NULL);
INSERT INTO `Person` VALUES(92, 'Christopher', 'Walken', 1, NULL);
INSERT INTO `Person` VALUES(93, 'Meryl', 'Streep', 0, NULL);
INSERT INTO `Person` VALUES(94, 'Frank', 'Miller', 1, NULL);
INSERT INTO `Person` VALUES(95, 'Jessica', 'Alba', 0, NULL);
INSERT INTO `Person` VALUES(96, 'Mickey', 'Rourke', 1, NULL);
INSERT INTO `Person` VALUES(97, 'Elijah', 'Wood', 1, NULL);
INSERT INTO `Person` VALUES(98, 'Tom', 'Hooper', 1, NULL);
INSERT INTO `Person` VALUES(99, 'Colin', 'Firth', NULL, NULL);
INSERT INTO `Person` VALUES(100, 'Sean', 'Penn', 1, NULL);
INSERT INTO `Person` VALUES(101, 'Gus', 'Van Sant', 1, NULL);
INSERT INTO `Person` VALUES(102, 'Robin', 'Williams', 1, NULL);
INSERT INTO `Person` VALUES(103, 'Ben', 'Affleck', NULL, NULL);
INSERT INTO `Person` VALUES(104, 'Casey', 'Affleck', 1, NULL);
INSERT INTO `Person` VALUES(105, 'Terry', 'Gilliam', 1, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `Productor`
--

CREATE TABLE `Productor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Productor_id` int(11) NOT NULL,
  `Movie_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ProductorMovie_uk` (`Productor_id`,`Movie_id`),
  KEY `Productor2Movie_fk` (`Movie_id`),
  KEY `Productor2Person_fk` (`Productor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `Productor`
--


-- --------------------------------------------------------

--
-- Structure de la vue `Node`
--
DROP TABLE IF EXISTS `Node`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `Node` AS (select concat('m',`m`.`id`) AS `id`,`m`.`Title` AS `label` from `Movie` `m`) union (select concat('p',`p`.`id`) AS `id`,concat(`p`.`FirstName`,' ',`p`.`LastName`) AS `label` from `Person` `p`);
